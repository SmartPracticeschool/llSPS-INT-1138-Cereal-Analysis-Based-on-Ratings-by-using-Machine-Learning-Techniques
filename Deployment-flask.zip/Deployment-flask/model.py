#!/usr/bin/env python
# coding: utf-8

# In[497]:


import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')
from sklearn import preprocessing
import pickle


# In[498]:



data=pd.read_csv("cereal.csv")
data


# In[499]:


data.apply(lambda x: sum(x.isnull()),axis=0)


# In[500]:


from sklearn.preprocessing import LabelEncoder
lb=LabelEncoder()
lb2=LabelEncoder()
data['type']=lb.fit_transform(data['type'])
data


# In[501]:


x=data.iloc[:,2:15]


# In[502]:


y=data.iloc[:,15].values


# In[503]:


minmax=preprocessing.MinMaxScaler(feature_range=(0,1))
minmax.fit(x).transform(x)


# In[504]:


x


# In[505]:


from sklearn import model_selection, neighbors
from sklearn.model_selection import train_test_split,cross_val_score,cross_val_predict
x_train, x_test, y_train, y_test = train_test_split(x,y,test_size=0.3,random_state=1)


# In[506]:


import statsmodels.api as sm


# In[507]:


x=data[["type","calories","sodium","fiber","carbo","potass"]]
y=data["rating"]


# In[508]:


model1 = sm.OLS(y,x).fit()
predictions = model1.predict(x)
model1.summary()


# In[509]:


from sklearn import model_selection, neighbors
from sklearn.model_selection import train_test_split,cross_val_score,cross_val_predict
x_train, x_test, y_train, y_test = train_test_split(x,y,test_size=0.3,random_state=1)


# In[510]:


# define the data/predictors as the pre-set feature names  
features = x_train.iloc[:,:].values
labels = y_train.iloc[:].values
x=features
y=labels


# In[511]:


# Instantiate Multiple linear regrssion model
from sklearn import linear_model as lm
regressor=lm.LinearRegression()
results=regressor.fit(x,y) 


# In[512]:


predictions = regressor.predict(x)


# In[513]:


accuracy=regressor.score(x,y)
accuracy


# In[514]:


#Evaluating the model 
from sklearn.metrics import mean_squared_error, r2_score

# printing values
'''print('Slope:' ,model.coef_)
print('Intercept:', model.intercept_)
print("\n")'''


import numpy as np
rmse = (np.sqrt(mean_squared_error(y,predictions)))
r2 = r2_score(y,predictions)

print("The model performance")
print("--------------------------------------")
print('RMSE is {}'.format(rmse))
print('R2 score is {}'.format(r2))
print("\n")


# In[515]:


# define the data/predictors as the pre-set feature names  
features = x_test.iloc[:,:].values
labels = y_test.iloc[:].values
x=features
y=labels


# In[516]:


# Instantiate Multiple linear regrssion model
from sklearn import linear_model as lm
regressor=lm.LinearRegression()
results=regressor.fit(x,y) 


# In[517]:


predictions = regressor.predict(x)
pickle.dump(regressor,open('cereal.pkl','wb'))
model=pickle.load(open('cereal.pkl','rb'))
print(model.predict([[0,70,130,10,5,280]]))


# In[518]:


accuracy=regressor.score(x,y)
accuracy


# In[519]:


#Evaluating the model 
from sklearn.metrics import mean_squared_error, r2_score

# printing values
'''print('Slope:' ,model.coef_)
print('Intercept:', model.intercept_)
print("\n")'''


import numpy as np
rmse = (np.sqrt(mean_squared_error(y,predictions)))
r2 = r2_score(y,predictions)

print("The model performance")
print("--------------------------------------")
print('RMSE is {}'.format(rmse))
print('R2 score is {}'.format(r2))
print("\n")


# In[ ]:





# In[ ]:





# In[ ]:




