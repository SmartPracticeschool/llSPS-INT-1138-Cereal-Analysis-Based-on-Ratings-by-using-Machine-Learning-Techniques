import requests

url = 'http://localhost:5000/predict_api'
r = requests.post(url,json={'type':0, 'calories':70, 'sodium':130,'fiber':10,'carbo':5,'potass':280})

print(r.json())
